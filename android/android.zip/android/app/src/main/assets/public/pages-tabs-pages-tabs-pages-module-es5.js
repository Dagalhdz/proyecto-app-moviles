(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-tabs-pages-tabs-pages-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tabs-pages/tabs-pages.page.html":
    /*!*********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tabs-pages/tabs-pages.page.html ***!
      \*********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesTabsPagesTabsPagesPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-tabs>\n    <ion-tab-bar slot=\"buttom\">\n        <ion-tab-button tab=\"autos\">\n            <ion-icon name=\"car-sport-outline\"></ion-icon>\n            <ion-label>Autos</ion-label>\n        </ion-tab-button>\n        <ion-tab-button tab=\"mapa\">\n            <ion-icon name=\"map-outline\"></ion-icon>\n            <ion-label>Mapa</ion-label>\n        </ion-tab-button>\n        <ion-tab-button tab=\"cambio-auto\">\n            <ion-icon name=\"repeat-outline\"></ion-icon>\n            <ion-label>Cambio de Auto</ion-label>\n        </ion-tab-button>\n        <ion-tab-button tab=\"info\">\n            <ion-icon name=\"information-circle-outline\"></ion-icon>\n            <ion-label>Acerca de</ion-label>\n        </ion-tab-button>\n    </ion-tab-bar>\n</ion-tabs>";
      /***/
    },

    /***/
    "./src/app/pages/tabs-pages/tabs-pages-routing.module.ts":
    /*!***************************************************************!*\
      !*** ./src/app/pages/tabs-pages/tabs-pages-routing.module.ts ***!
      \***************************************************************/

    /*! exports provided: TabsPagesPageRoutingModule */

    /***/
    function srcAppPagesTabsPagesTabsPagesRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TabsPagesPageRoutingModule", function () {
        return TabsPagesPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _tabs_pages_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./tabs-pages.page */
      "./src/app/pages/tabs-pages/tabs-pages.page.ts");

      var routes = [{
        path: '',
        component: _tabs_pages_page__WEBPACK_IMPORTED_MODULE_3__["TabsPagesPage"],
        children: [{
          path: 'autos',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | autos-autos-module */
            [__webpack_require__.e("default~autos-autos-module~pages-busqueda-busqueda-module~pages-info-autos-info-autos-module"), __webpack_require__.e("common"), __webpack_require__.e("autos-autos-module")]).then(__webpack_require__.bind(null,
            /*! ../autos/autos.module */
            "./src/app/pages/autos/autos.module.ts")).then(function (m) {
              return m.AutosPageModule;
            });
          }
        }, {
          path: 'mapa',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | mapa-mapa-module */
            [__webpack_require__.e("common"), __webpack_require__.e("mapa-mapa-module")]).then(__webpack_require__.bind(null,
            /*! ../mapa/mapa.module */
            "./src/app/pages/mapa/mapa.module.ts")).then(function (m) {
              return m.MapaPageModule;
            });
          }
        }, {
          path: 'info',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | info-info-module */
            [__webpack_require__.e("common"), __webpack_require__.e("info-info-module")]).then(__webpack_require__.bind(null,
            /*! ../info/info.module */
            "./src/app/pages/info/info.module.ts")).then(function (m) {
              return m.InfoPageModule;
            });
          }
        }, {
          path: 'cambio-auto',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | cambio-auto-cambio-auto-module */
            [__webpack_require__.e("common"), __webpack_require__.e("cambio-auto-cambio-auto-module")]).then(__webpack_require__.bind(null,
            /*! ../cambio-auto/cambio-auto.module */
            "./src/app/pages/cambio-auto/cambio-auto.module.ts")).then(function (m) {
              return m.CambioAutoPageModule;
            });
          }
        }]
      }];

      var TabsPagesPageRoutingModule = function TabsPagesPageRoutingModule() {
        _classCallCheck(this, TabsPagesPageRoutingModule);
      };

      TabsPagesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], TabsPagesPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/tabs-pages/tabs-pages.module.ts":
    /*!*******************************************************!*\
      !*** ./src/app/pages/tabs-pages/tabs-pages.module.ts ***!
      \*******************************************************/

    /*! exports provided: TabsPagesPageModule */

    /***/
    function srcAppPagesTabsPagesTabsPagesModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TabsPagesPageModule", function () {
        return TabsPagesPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _tabs_pages_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./tabs-pages-routing.module */
      "./src/app/pages/tabs-pages/tabs-pages-routing.module.ts");
      /* harmony import */


      var _tabs_pages_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./tabs-pages.page */
      "./src/app/pages/tabs-pages/tabs-pages.page.ts");

      var TabsPagesPageModule = function TabsPagesPageModule() {
        _classCallCheck(this, TabsPagesPageModule);
      };

      TabsPagesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _tabs_pages_routing_module__WEBPACK_IMPORTED_MODULE_5__["TabsPagesPageRoutingModule"]],
        declarations: [_tabs_pages_page__WEBPACK_IMPORTED_MODULE_6__["TabsPagesPage"]]
      })], TabsPagesPageModule);
      /***/
    },

    /***/
    "./src/app/pages/tabs-pages/tabs-pages.page.scss":
    /*!*******************************************************!*\
      !*** ./src/app/pages/tabs-pages/tabs-pages.page.scss ***!
      \*******************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesTabsPagesTabsPagesPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-tab-button[aria-selected=true] {\n  box-shadow: 0 2px 0 0 blue inset;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdGFicy1wYWdlcy90YWJzLXBhZ2VzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdDQUFBO0FBQ0oiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy90YWJzLXBhZ2VzL3RhYnMtcGFnZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRhYi1idXR0b25bYXJpYS1zZWxlY3RlZD10cnVlXSB7XHJcbiAgICBib3gtc2hhZG93OiAwIDJweCAwIDAgYmx1ZSBpbnNldDtcclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/pages/tabs-pages/tabs-pages.page.ts":
    /*!*****************************************************!*\
      !*** ./src/app/pages/tabs-pages/tabs-pages.page.ts ***!
      \*****************************************************/

    /*! exports provided: TabsPagesPage */

    /***/
    function srcAppPagesTabsPagesTabsPagesPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TabsPagesPage", function () {
        return TabsPagesPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var TabsPagesPage = /*#__PURE__*/function () {
        function TabsPagesPage() {
          _classCallCheck(this, TabsPagesPage);
        }

        _createClass(TabsPagesPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return TabsPagesPage;
      }();

      TabsPagesPage.ctorParameters = function () {
        return [];
      };

      TabsPagesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tabs-pages',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./tabs-pages.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tabs-pages/tabs-pages.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./tabs-pages.page.scss */
        "./src/app/pages/tabs-pages/tabs-pages.page.scss"))["default"]]
      })], TabsPagesPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-tabs-pages-tabs-pages-module-es5.js.map