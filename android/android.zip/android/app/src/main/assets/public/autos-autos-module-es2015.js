(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["autos-autos-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/autos/autos.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/autos/autos.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-header></app-header>\r\n<ion-content class=\"ion-padding\">\r\n    <ion-segment scrollable (ionChange)=\"onFilter($event)\">\r\n        <ion-segment-button value=\"Deportivo\">Deportivo</ion-segment-button>\r\n        <ion-segment-button value=\"camioneta\">Camioneta</ion-segment-button>\r\n        <ion-segment-button value=\"electrico\">Electrico</ion-segment-button>\r\n        <ion-segment-button value=\"comercial\">Comercial</ion-segment-button>\r\n        <ion-segment-button value=\"familiar\">Familiar</ion-segment-button>\r\n        <ion-segment-button value=\"Convertible\">Convertible</ion-segment-button>\r\n    </ion-segment>\r\n\r\n    <ion-card>\r\n        <ion-card-header>\r\n            <ion-card-title>{{autos.modelo}}</ion-card-title>\r\n            <ion-card-subtitle>{{autos.marca}}</ion-card-subtitle>\r\n            <ion-img [src]=\"autos.imgInicial\"></ion-img>\r\n        </ion-card-header>\r\n        <ion-label class=\"ion-padding\">Especificaciones: </ion-label>\r\n        <ion-card-content [innerHTML]=\"autos.infoGeneral\">\r\n            <!-- {{autos.infoGeneral}} -->\r\n        </ion-card-content>\r\n\r\n        <ion-button color=\"dark\" expand=\"block\" fill=\"outline\" (click)=\"verAuto()\">ver mas...</ion-button>\r\n\r\n    </ion-card>\r\n\r\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/autos/autos-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/autos/autos-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: AutosPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AutosPageRoutingModule", function() { return AutosPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _autos_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./autos.page */ "./src/app/pages/autos/autos.page.ts");




const routes = [
    {
        path: '',
        component: _autos_page__WEBPACK_IMPORTED_MODULE_3__["AutosPage"]
    }
];
let AutosPageRoutingModule = class AutosPageRoutingModule {
};
AutosPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AutosPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/autos/autos.module.ts":
/*!*********************************************!*\
  !*** ./src/app/pages/autos/autos.module.ts ***!
  \*********************************************/
/*! exports provided: AutosPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AutosPageModule", function() { return AutosPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _header_header_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../header/header.page */ "./src/app/pages/header/header.page.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _autos_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./autos-routing.module */ "./src/app/pages/autos/autos-routing.module.ts");
/* harmony import */ var _autos_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./autos.page */ "./src/app/pages/autos/autos.page.ts");








let AutosPageModule = class AutosPageModule {
};
AutosPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _autos_routing_module__WEBPACK_IMPORTED_MODULE_6__["AutosPageRoutingModule"],
        ],
        declarations: [_autos_page__WEBPACK_IMPORTED_MODULE_7__["AutosPage"], _header_header_page__WEBPACK_IMPORTED_MODULE_1__["HeaderPage"]]
    })
], AutosPageModule);



/***/ }),

/***/ "./src/app/pages/autos/autos.page.scss":
/*!*********************************************!*\
  !*** ./src/app/pages/autos/autos.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@import url(\"https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@1,600&display=swap\");\n* {\n  font-family: \"Montserrat\", sans-serif;\n}\nion-img {\n  padding-top: 5px;\n  padding-bottom: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYXV0b3MvYXV0b3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFRLCtGQUFBO0FBQ1I7RUFDSSxxQ0FBQTtBQUNKO0FBRUE7RUFDSSxnQkFBQTtFQUNBLG1CQUFBO0FBQ0oiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9hdXRvcy9hdXRvcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAaW1wb3J0IHVybCgnaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3MyP2ZhbWlseT1Nb250c2VycmF0Oml0YWwsd2dodEAxLDYwMCZkaXNwbGF5PXN3YXAnKTtcclxuKiB7XHJcbiAgICBmb250LWZhbWlseTogJ01vbnRzZXJyYXQnLCBzYW5zLXNlcmlmO1xyXG59XHJcblxyXG5pb24taW1nIHtcclxuICAgIHBhZGRpbmctdG9wOiA1cHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNXB4O1xyXG59Il19 */");

/***/ }),

/***/ "./src/app/pages/autos/autos.page.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/autos/autos.page.ts ***!
  \*******************************************/
/*! exports provided: AutosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AutosPage", function() { return AutosPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _services_autos_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../services/autos.service */ "./src/app/services/autos.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");




let AutosPage = class AutosPage {
    constructor(autoService, _router) {
        this.autoService = autoService;
        this._router = _router;
    }
    ngOnInit() {
        this.autos = this.autoService.obtenerAutoTipo('deportivo');
    }
    onFilter(event) {
        // console.log(this.autoService.obtenerAutoTipo(event.detail.value));
        this.autos = this.autoService.obtenerAutoTipo(event.detail.value);
    }
    verAuto() {
        this._router.navigate(['/info-auto', this.autos.id]);
    }
};
AutosPage.ctorParameters = () => [
    { type: _services_autos_service__WEBPACK_IMPORTED_MODULE_1__["AutosService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
AutosPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-autos',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./autos.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/autos/autos.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./autos.page.scss */ "./src/app/pages/autos/autos.page.scss")).default]
    })
], AutosPage);



/***/ })

}]);
//# sourceMappingURL=autos-autos-module-es2015.js.map