(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cambio-auto-cambio-auto-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cambio-auto/cambio-auto.page.html":
    /*!***********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cambio-auto/cambio-auto.page.html ***!
      \***********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesCambioAutoCambioAutoPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-header></app-header>\n<ion-content class=\"ion-padding-top\">\n\n    <ion-item class=\"ion-text-justify\">\n        <p>\n            Para utilizar el servicio de cambio de auto llenar el siguiente formulario y Capturar una foto de su auto para realizar una evaluacion del mismo. Gracias\n        </p>\n    </ion-item>\n    <hr>\n    <form>\n        <ion-item lines=\"full\">\n            <ion-label position=\"floating\">Nombre:</ion-label>\n            <ion-input type=\"text\" required></ion-input>\n        </ion-item>\n\n        <ion-item lines=\"full\">\n            <ion-label position=\"floating\">Apellido:</ion-label>\n            <ion-input type=\"text\" required></ion-input>\n        </ion-item>\n\n        <ion-item lines=\"full\">\n            <ion-label position=\"floating\">Edad:</ion-label>\n            <ion-input type=\"text\" required></ion-input>\n        </ion-item>\n\n        <ion-item lines=\"full\">\n            <ion-label position=\"floating\">E-mail</ion-label>\n            <ion-input type=\"email\" required></ion-input>\n        </ion-item>\n\n        <ion-item lines=\"full\">\n            <ion-label position=\"floating\">Telefono</ion-label>\n            <ion-input type=\"text\" required></ion-input>\n        </ion-item>\n\n        <ion-row>\n            <ion-col size-md=\"6\">\n                <ion-item lines=\"full\">\n                    <ion-label position=\"floating\">Marca</ion-label>\n                    <ion-input type=\"email\" required></ion-input>\n                </ion-item>\n            </ion-col>\n            <ion-col size-sm=\"6\">\n                <ion-item lines=\"full\">\n                    <ion-label position=\"floating\">Modelo</ion-label>\n                    <ion-input type=\"text\" required></ion-input>\n                </ion-item>\n            </ion-col>\n        </ion-row>\n\n        <div style=\"text-align:center\">\n            <ion-button (click)=\"capturarImagen()\">\n                Tomar Foto\n            </ion-button>\n        </div>\n\n        <img [src]=\"clickedImage\" />\n        <div style=\"text-align:center\">\n            <ion-button (click)=\"onEnviar()\">\n                Enviar\n            </ion-button>\n        </div>\n    </form>\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/pages/cambio-auto/cambio-auto-routing.module.ts":
    /*!*****************************************************************!*\
      !*** ./src/app/pages/cambio-auto/cambio-auto-routing.module.ts ***!
      \*****************************************************************/

    /*! exports provided: CambioAutoPageRoutingModule */

    /***/
    function srcAppPagesCambioAutoCambioAutoRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CambioAutoPageRoutingModule", function () {
        return CambioAutoPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _cambio_auto_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./cambio-auto.page */
      "./src/app/pages/cambio-auto/cambio-auto.page.ts");

      var routes = [{
        path: '',
        component: _cambio_auto_page__WEBPACK_IMPORTED_MODULE_3__["CambioAutoPage"]
      }];

      var CambioAutoPageRoutingModule = function CambioAutoPageRoutingModule() {
        _classCallCheck(this, CambioAutoPageRoutingModule);
      };

      CambioAutoPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], CambioAutoPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/cambio-auto/cambio-auto.module.ts":
    /*!*********************************************************!*\
      !*** ./src/app/pages/cambio-auto/cambio-auto.module.ts ***!
      \*********************************************************/

    /*! exports provided: CambioAutoPageModule */

    /***/
    function srcAppPagesCambioAutoCambioAutoModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CambioAutoPageModule", function () {
        return CambioAutoPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _header_header_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./../header/header.page */
      "./src/app/pages/header/header.page.ts");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _cambio_auto_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./cambio-auto-routing.module */
      "./src/app/pages/cambio-auto/cambio-auto-routing.module.ts");
      /* harmony import */


      var _cambio_auto_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./cambio-auto.page */
      "./src/app/pages/cambio-auto/cambio-auto.page.ts");

      var CambioAutoPageModule = function CambioAutoPageModule() {
        _classCallCheck(this, CambioAutoPageModule);
      };

      CambioAutoPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _cambio_auto_routing_module__WEBPACK_IMPORTED_MODULE_6__["CambioAutoPageRoutingModule"]],
        declarations: [_cambio_auto_page__WEBPACK_IMPORTED_MODULE_7__["CambioAutoPage"], _header_header_page__WEBPACK_IMPORTED_MODULE_1__["HeaderPage"]]
      })], CambioAutoPageModule);
      /***/
    },

    /***/
    "./src/app/pages/cambio-auto/cambio-auto.page.scss":
    /*!*********************************************************!*\
      !*** ./src/app/pages/cambio-auto/cambio-auto.page.scss ***!
      \*********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesCambioAutoCambioAutoPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-item {\n  padding-bottom: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY2FtYmlvLWF1dG8vY2FtYmlvLWF1dG8ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksb0JBQUE7QUFDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2NhbWJpby1hdXRvL2NhbWJpby1hdXRvLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pdGVtIHtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxMHB4O1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/pages/cambio-auto/cambio-auto.page.ts":
    /*!*******************************************************!*\
      !*** ./src/app/pages/cambio-auto/cambio-auto.page.ts ***!
      \*******************************************************/

    /*! exports provided: CambioAutoPage */

    /***/
    function srcAppPagesCambioAutoCambioAutoPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CambioAutoPage", function () {
        return CambioAutoPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @ionic-native/camera/ngx */
      "./node_modules/@ionic-native/camera/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var CambioAutoPage = /*#__PURE__*/function () {
        function CambioAutoPage(camera) {
          _classCallCheck(this, CambioAutoPage);

          this.camera = camera;
          this.options = {
            quality: 30,
            destinationType: this.camera.DestinationType.DATA_URL,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
          };
        }

        _createClass(CambioAutoPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "capturarImagen",
          value: function capturarImagen() {
            var _this = this;

            this.camera.getPicture(this.options).then(function (imageData) {
              var base64Image = 'data:image/jpeg;base64,' + imageData;
              _this.clickedImage = base64Image;
            }, function (err) {
              console.log(err);
            });
          }
        }, {
          key: "onEnviar",
          value: function onEnviar() {
            alert('Informacion enviada Correctamente');
          }
        }]);

        return CambioAutoPage;
      }();

      CambioAutoPage.ctorParameters = function () {
        return [{
          type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_1__["Camera"]
        }];
      };

      CambioAutoPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: "app-cambio-auto",
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./cambio-auto.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cambio-auto/cambio-auto.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./cambio-auto.page.scss */
        "./src/app/pages/cambio-auto/cambio-auto.page.scss"))["default"]]
      })], CambioAutoPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=cambio-auto-cambio-auto-module-es5.js.map