(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-info-autos-info-autos-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-autos/info-autos.page.html":
    /*!*********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-autos/info-autos.page.html ***!
      \*********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesInfoAutosInfoAutosPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-back-button defailtHref=\"tabs-pages/autos\"></ion-back-button>\n        </ion-buttons>\n        <ion-buttons slot=\"primary\">\n            <ion-button (click)=\"onPlay()\" slot=\"icon-slot\">\n                <ion-icon name=\"videocam-outline\"></ion-icon>\n            </ion-button>\n        </ion-buttons>\n        <ion-title>{{auto.modelo}}</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n    <ion-segment (ionChange)=\"onFilter($event)\">\n        <ion-segment-button value=\"interior\">Interior</ion-segment-button>\n        <ion-segment-button value=\"exterior\">Exterior</ion-segment-button>\n    </ion-segment>\n\n    <ion-card>\n        <ion-slides pager=\"true\" class=\"slide-padding\">\n            <ion-slide>\n                <ion-img [src]=\"info[0]\"></ion-img>\n            </ion-slide>\n\n            <ion-slide>\n                <ion-img [src]=\"info[1]\"></ion-img>\n            </ion-slide>\n\n        </ion-slides>\n        <ion-card-content [innerHtml]=\"info[2]\" class=\"ion-text-justify\"></ion-card-content>\n    </ion-card>\n\n    <ion-card>\n        <ion-card-title>Informacion Detallada</ion-card-title>\n        <ion-img [src]=\"auto.imgInfo\"></ion-img>\n    </ion-card>\n\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/pages/info-autos/info-autos-routing.module.ts":
    /*!***************************************************************!*\
      !*** ./src/app/pages/info-autos/info-autos-routing.module.ts ***!
      \***************************************************************/

    /*! exports provided: InfoAutosPageRoutingModule */

    /***/
    function srcAppPagesInfoAutosInfoAutosRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "InfoAutosPageRoutingModule", function () {
        return InfoAutosPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _info_autos_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./info-autos.page */
      "./src/app/pages/info-autos/info-autos.page.ts");

      var routes = [{
        path: '',
        component: _info_autos_page__WEBPACK_IMPORTED_MODULE_3__["InfoAutosPage"]
      }];

      var InfoAutosPageRoutingModule = function InfoAutosPageRoutingModule() {
        _classCallCheck(this, InfoAutosPageRoutingModule);
      };

      InfoAutosPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], InfoAutosPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/info-autos/info-autos.module.ts":
    /*!*******************************************************!*\
      !*** ./src/app/pages/info-autos/info-autos.module.ts ***!
      \*******************************************************/

    /*! exports provided: InfoAutosPageModule */

    /***/
    function srcAppPagesInfoAutosInfoAutosModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "InfoAutosPageModule", function () {
        return InfoAutosPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _info_autos_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./info-autos-routing.module */
      "./src/app/pages/info-autos/info-autos-routing.module.ts");
      /* harmony import */


      var _info_autos_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./info-autos.page */
      "./src/app/pages/info-autos/info-autos.page.ts");

      var InfoAutosPageModule = function InfoAutosPageModule() {
        _classCallCheck(this, InfoAutosPageModule);
      };

      InfoAutosPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _info_autos_routing_module__WEBPACK_IMPORTED_MODULE_5__["InfoAutosPageRoutingModule"]],
        declarations: [_info_autos_page__WEBPACK_IMPORTED_MODULE_6__["InfoAutosPage"]]
      })], InfoAutosPageModule);
      /***/
    },

    /***/
    "./src/app/pages/info-autos/info-autos.page.scss":
    /*!*******************************************************!*\
      !*** ./src/app/pages/info-autos/info-autos.page.scss ***!
      \*******************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesInfoAutosInfoAutosPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-img {\n  padding-top: 5px;\n  padding-bottom: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaW5mby1hdXRvcy9pbmZvLWF1dG9zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0VBQ0EsbUJBQUE7QUFDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2luZm8tYXV0b3MvaW5mby1hdXRvcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taW1nIHtcclxuICAgIHBhZGRpbmctdG9wOiA1cHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogNXB4O1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/pages/info-autos/info-autos.page.ts":
    /*!*****************************************************!*\
      !*** ./src/app/pages/info-autos/info-autos.page.ts ***!
      \*****************************************************/

    /*! exports provided: InfoAutosPage */

    /***/
    function srcAppPagesInfoAutosInfoAutosPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "InfoAutosPage", function () {
        return InfoAutosPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _services_autos_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./../../services/autos.service */
      "./src/app/services/autos.service.ts");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_native_video_player_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic-native/video-player/ngx */
      "./node_modules/@ionic-native/video-player/__ivy_ngcc__/ngx/index.js");

      var InfoAutosPage = /*#__PURE__*/function () {
        function InfoAutosPage(_autoService, activatedRoute, videoPlayer) {
          var _this = this;

          _classCallCheck(this, InfoAutosPage);

          this._autoService = _autoService;
          this.activatedRoute = activatedRoute;
          this.videoPlayer = videoPlayer;
          this.info = [];
          this.activatedRoute.params.subscribe(function (params) {
            // console.log(params["id"] - 1);
            _this.auto = _this._autoService.getAuto(params["id"] - 1); // console.log(this.auto);
          });
        }

        _createClass(InfoAutosPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.info = [this.auto.imgInterior1, this.auto.imgInterior2, this.auto.infoInterior]; // console.log(this.info);
          }
        }, {
          key: "onFilter",
          value: function onFilter(event) {
            if (event.detail.value === "interior") {
              this.info = [this.auto.imgInterior1, this.auto.imgInterior2, this.auto.infoInterior];
            } else {
              this.info = [this.auto.imgExterior1, this.auto.imgExterior2, this.auto.infoExterior];
            }
          }
        }, {
          key: "onPlay",
          value: function onPlay() {
            // console.log('PlayVideo')
            this.videoPlayer.play('http://static.videogular.com/assets/videos/elephants-dream.mp4').then(function () {
              console.log("video completed");
            })["catch"](function (err) {
              console.log(err);
            });
          }
        }]);

        return InfoAutosPage;
      }();

      InfoAutosPage.ctorParameters = function () {
        return [{
          type: _services_autos_service__WEBPACK_IMPORTED_MODULE_1__["AutosService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
        }, {
          type: _ionic_native_video_player_ngx__WEBPACK_IMPORTED_MODULE_4__["VideoPlayer"]
        }];
      };

      InfoAutosPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: "app-info-autos",
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./info-autos.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/info-autos/info-autos.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./info-autos.page.scss */
        "./src/app/pages/info-autos/info-autos.page.scss"))["default"]]
      })], InfoAutosPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-info-autos-info-autos-module-es5.js.map